# Churn Prediction

Predict customer churn using machine learning and behavior data.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
