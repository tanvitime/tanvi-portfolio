# Hr Analytics

Explore employee attrition and satisfaction using HR datasets.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
