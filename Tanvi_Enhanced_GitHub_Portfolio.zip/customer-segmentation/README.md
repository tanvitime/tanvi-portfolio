# Customer Segmentation

Cluster customers into segments using demographic and behavioral features.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
