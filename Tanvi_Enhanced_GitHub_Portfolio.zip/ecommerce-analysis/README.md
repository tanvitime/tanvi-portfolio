# Ecommerce Analysis

Analyze customer behavior and spending patterns from an ecommerce platform.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
