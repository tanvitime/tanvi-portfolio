# Bank Transaction Analysis

Analyze banking transactions to identify trends and financial behaviors.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
