# 👋 Hi, I’m Tanvi Singh

🎓 First-year B.Tech student in **Artificial Intelligence & Data Science**  
🏫 Indira College of Engineering and Management, Pune  
🔍 Passionate about **Data Analysis, Machine Learning**, and building real-world Python projects  
📚 Actively learning Python, pandas, SQL, and AI/ML tools through hands-on projects  
📫 **Email:** Tanvisinghoff8055@gmail.com

## 📈 Projects

- 🔄 [Churn Prediction](./churn-prediction)
- 🛒 [Ecommerce Sales Analysis](./ecommerce-analysis)
- 🎯 [Customer Segmentation](./customer-segmentation)
- 👨‍💼 [HR Analytics](./hr-analytics)
- 🏦 [Bank Transaction Analysis](./bank-transaction-analysis)
