# Hr Analytics

Explore attrition, satisfaction, and employee performance data for insights.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
