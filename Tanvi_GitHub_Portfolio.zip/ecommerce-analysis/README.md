# Ecommerce Analysis

Analyze customer behavior, spending patterns, and trends across regions.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
