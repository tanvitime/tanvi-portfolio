# Bank Transaction Analysis

Analyze banking transactions to find patterns and predict financial trends.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
