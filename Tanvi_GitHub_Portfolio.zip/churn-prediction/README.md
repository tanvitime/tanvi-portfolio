# Churn Prediction

Predict customer churn using ML models and behavior data.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
