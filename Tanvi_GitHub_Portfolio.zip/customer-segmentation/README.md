# Customer Segmentation

Cluster customers into segments using behavioral and demographic features.

## Tools Used
- Python
- pandas
- seaborn
- scikit-learn
